## ----echo=FALSE,cache=FALSE----------------------------------------------
set.seed(1234)
knitr::opts_chunk$set(cache=TRUE)

