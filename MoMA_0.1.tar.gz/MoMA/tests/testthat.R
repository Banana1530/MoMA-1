library(testthat)
library(MoMA)

test_check("MoMA")
