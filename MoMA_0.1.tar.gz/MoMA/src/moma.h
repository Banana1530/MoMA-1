// -*- mode: C++; c-indent-level: 4; c-basic-offset: 4; indent-tabs-mode: nil; -*-
#include <sstream>
// We only include RcppArmadillo.h which pulls Rcpp.h in for us
#include "RcppArmadillo.h"

// Logging code
#include "moma_logging.h"

